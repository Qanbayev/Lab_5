
let result = document.getElementById('result');

function appendToDisplay(value) {
    result.value += value;
}

function calculate() {
    try {
        result.value = eval(result.value);
    } catch (error) {
        result.value = 'Xəta baş verdi';
    }
}

function operate(operator) {
    result.value += operator;
}





